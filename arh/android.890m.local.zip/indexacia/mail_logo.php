<!-- Rating@Mail.ru logo -->
<a href="http://top.mail.ru/jump?from=2650787">
<img src="//top-fwz1.mail.ru/counter?id=2650787;t=479;l=1" 
style="border:0;" height="31" width="88" alt="�������@Mail.ru" /></a>
<!-- //Rating@Mail.ru logo -->
