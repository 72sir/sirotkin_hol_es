function hideShowDiv(){
      $('#les8_ex2').toggle('slow');
}