



<meta name="title" content="<? echo($title); ?>"/>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8 /">
<meta http-equiv="Content-Style-Type" content="text/css">

<meta http-equiv="content-language" content="ru">

<meta name="keywords" content="<?php echo($title);?>">
<meta name="description" content="<?php echo($title);?>">

<meta name="author" content="<?php echo($author);?>">
<meta name="copyright" content="<?php echo($copyright);?>">


<meta name="robots" content="all"/> 

<meta name='wmail-verification' content='d15e7f461f862b0e2b5e218b48ec7ea1' />

<link rel="stylesheet" href="style.css" type="text/css" media="screen, projection">

<link rel="shortcut icon" href="">

<link rel="stylesheet"href="highlighter/prettify.css"/>

<script type="text/javascript" src="http://vk.com/js/api/share.js?90" charset="windows-1251"></script>

