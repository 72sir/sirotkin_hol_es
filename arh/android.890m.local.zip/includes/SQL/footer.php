<!--p id="pata"--> 

<a href="http://api.hostinger.ru/redir/7978353" target="_blank">
<img src="http://www.hostinger.ru/banners/ru/hostinger-728x90-1.gif" alt="�������" border="0" width="800" height="90" /></a>


<!--/p-->
