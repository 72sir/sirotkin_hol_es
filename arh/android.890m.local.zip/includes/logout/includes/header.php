<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
    <title>Регистрация пользователя</title>
	<link href="css/style.css" media="screen" rel="stylesheet">
	<link href='' rel='stylesheet' type='text/css'>
</head> 

	<body>
	