<?php

// Database Constants
define("DB_SERVER", "localhost");
define("DB_USER", "u991204542_890m");
define("DB_PASS", "ZPpkW4QDMM");
define("DB_NAME", "u991204542_890m");

define("Loc_welcome", "http://android.890m.local/");

?>