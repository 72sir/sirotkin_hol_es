﻿module WebReports.Utils.Class {
    export function CommonClass(a, b): any[] {
        let result = a + b;
        return result;
    }
}
